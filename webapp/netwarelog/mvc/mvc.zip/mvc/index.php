<?php
	require "../../netwarelog/mvc/index.php";
?>
