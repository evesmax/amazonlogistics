<?php
    require "../../netwarelog/mvc/ajax.php";
?>
