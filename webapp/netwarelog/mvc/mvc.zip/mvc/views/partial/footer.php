<br/>
<footer>
    <div style='text-align:center; width:100%; clear:both;'>Acontia 2.1</div>
</footer>

</body>
<SCRIPT language=javascript>
<!-- 
ap_showWaitMessage('waitDiv', 0); 
//-->
$.ajaxSetup({
  data: {Token:'1'} }
);
</SCRIPT>
</html>